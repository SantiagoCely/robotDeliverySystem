import MyWindowController  # noqa: F401
from PyObjCTools import AppHelper

AppHelper.runEventLoop()
