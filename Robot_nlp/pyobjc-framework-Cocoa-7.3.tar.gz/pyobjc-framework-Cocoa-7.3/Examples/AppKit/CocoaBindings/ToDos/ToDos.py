import ToDosDocument  # noqa: F401

if __name__ == "__main__":
    from PyObjCTools import AppHelper

    AppHelper.runEventLoop()
