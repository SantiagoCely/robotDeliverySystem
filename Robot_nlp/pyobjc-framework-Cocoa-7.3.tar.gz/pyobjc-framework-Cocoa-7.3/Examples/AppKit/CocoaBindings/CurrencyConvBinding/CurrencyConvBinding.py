# import classes required to start application
import Converter  # noqa: F401
import CurrencyConvBindingDocument  # noqa: F401
from PyObjCTools import AppHelper

if __name__ == "__main__":
    AppHelper.runEventLoop()
