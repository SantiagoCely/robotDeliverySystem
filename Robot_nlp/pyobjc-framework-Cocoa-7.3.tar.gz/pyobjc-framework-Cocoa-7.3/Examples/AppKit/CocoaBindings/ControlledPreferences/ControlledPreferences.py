#
#  ControlledPreferences
#
#

# import classes required to start application
import FontNameToDisplayNameTransformer  # noqa: F401
import FontSampleDisplayView  # noqa: F401
import PreferencesPanelController  # noqa: F401
from PyObjCTools import AppHelper

# start the event loop
AppHelper.runEventLoop()
