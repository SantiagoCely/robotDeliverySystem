#
#  __main__.py
#  TableModel
#
#  Created by Bob Ippolito on Sun Apr 04 2004.
#  Copyright (c) 2004 Bob Ippolito. All rights reserved.
#

# import classes required to start application
import TableModelAppDelegate  # noqa: F401
from PyObjCTools import AppHelper

# start the event loop
AppHelper.runEventLoop(argv=[])
