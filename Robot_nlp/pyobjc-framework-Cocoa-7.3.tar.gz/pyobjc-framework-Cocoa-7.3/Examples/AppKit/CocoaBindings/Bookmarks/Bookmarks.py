import BookmarksDocument  # noqa: F401
import DNDArrayController  # noqa: F401
import DNDTableView  # noqa: F401

if __name__ == "__main__":
    from PyObjCTools import AppHelper

    AppHelper.runEventLoop()
