# import classes required to start application
import AppController  # noqa: F401
from PyObjCTools import AppHelper

# start the event loop
AppHelper.runEventLoop()
