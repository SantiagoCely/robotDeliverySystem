# import classes required to start application
import TransformerAppDelegate  # noqa: F401
from PyObjCTools import AppHelper

if __name__ == "__main__":
    AppHelper.runEventLoop()
