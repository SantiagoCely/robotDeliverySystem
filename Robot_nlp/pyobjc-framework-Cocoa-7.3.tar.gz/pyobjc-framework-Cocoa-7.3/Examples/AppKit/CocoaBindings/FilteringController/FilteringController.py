#
#  FilteringController
#

import FilteringArrayController  # noqa: F401
import FilteringControllerDocument  # noqa: F401
from PyObjCTools import AppHelper

AppHelper.runEventLoop()
