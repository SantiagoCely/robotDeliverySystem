import CaseInsensitivePredicateTemplate  # noqa: F401
import MyWindowController  # noqa: F401
from PyObjCTools import AppHelper

AppHelper.runEventLoop()
