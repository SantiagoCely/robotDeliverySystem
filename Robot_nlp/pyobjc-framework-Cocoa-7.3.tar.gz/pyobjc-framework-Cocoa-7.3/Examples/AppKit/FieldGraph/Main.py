import CGraphController  # noqa: F401
import CGraphModel  # noqa: F401
import CGraphView  # noqa: F401
from PyObjCTools import AppHelper

AppHelper.runEventLoop()
