PyInterpreter

PyInterpreter is a full featured Python interpreter in a NSTextView.

See:    https://pyobjc.readthedocs.io/en/latest/
        https://wiki.python.org/moin/MacPython/PyInterpreter

Source for both the pyobjc module and PyInterpreter are
available via the pyobjc repository.

The source of this application demonstrates
- Advanced usage of NSTextView
- Manual event dispatching
- Text completion

Bob Ippolito
bob@redivi.com
