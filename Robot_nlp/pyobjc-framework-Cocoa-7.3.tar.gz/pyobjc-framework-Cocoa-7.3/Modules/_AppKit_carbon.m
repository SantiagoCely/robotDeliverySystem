/*
 * Support code for dealing with Carbon types (at least those
 * used in AppKit and wrapped in the python core).
 */

static int
setup_carbon(PyObject* m __attribute__((__unused__)))
{
    return 0;
}
