import AppKit  # noqa: F401
from PyObjCTools.TestSupport import TestCase


class TestNSMovieView(TestCase):
    pass
